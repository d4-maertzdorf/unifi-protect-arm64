#!/usr/bin/python3

import os
import subprocess
import sys
import time


bin_systemctl          = '/bin/systemctl'
service_unifi_protect  = 'unifi-protect.service'
srv_path               = '/srv'


if __name__ == "__main__":
    status = subprocess.call([bin_systemctl, 'status', service_unifi_protect], stdout=subprocess.DEVNULL)
    if 0 == status:
        sys.exit(0)

    if not os.path.islink(srv_path):
        sys.exit(0)

    target_path = os.readlink(srv_path)
    if not os.path.exists(target_path):
        sys.exit(2)

    status = subprocess.call([bin_systemctl, 'restart', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=60)
    if 0 != status:
        sys.exit(3)

    time.sleep(0.25)
    sys.exit(0)
