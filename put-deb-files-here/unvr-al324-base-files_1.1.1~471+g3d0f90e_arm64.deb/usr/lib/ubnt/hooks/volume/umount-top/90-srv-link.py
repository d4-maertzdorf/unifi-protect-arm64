#!/usr/bin/python3

import json
import os
import re
import sys


srv_path      = '/srv'
key_volumes   = 'volumes'


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(2)

    j_args = None
    try:
        j_args = json.loads(sys.argv[1])
    except:
        sys.exit(3)

    if not key_volumes in j_args.keys():
        sys.exit(4)

    volumes = j_args[key_volumes]

    if not os.path.islink(srv_path):
        sys.exit(0)

    target_path = os.readlink(srv_path)

    for volume in volumes:
        volume_re = r'^\{}\/'.format(volume)
        if re.match(volume_re, target_path):
            os.unlink(srv_path)
            break

    sys.exit(0)
