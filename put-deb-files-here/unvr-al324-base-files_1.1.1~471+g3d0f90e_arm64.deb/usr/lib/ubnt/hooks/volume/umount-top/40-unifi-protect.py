#!/usr/bin/python3

import json
import os
import re
import subprocess
import sys
import time


bin_systemctl          = '/bin/systemctl'
service_unifi_protect  = 'unifi-protect.service'
srv_path               = '/srv'
key_volumes            = 'volumes'


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(2)

    j_args = None
    try:
        j_args = json.loads(sys.argv[1])
    except:
        sys.exit(3)

    if not key_volumes in j_args.keys():
        sys.exit(4)

    volumes = j_args[key_volumes]

    status = subprocess.call([bin_systemctl, 'status', service_unifi_protect], stdout=subprocess.DEVNULL)
    if 0 != status:
        sys.exit(0)

    if not os.path.islink(srv_path):
        sys.exit(0)

    target_path = os.readlink(srv_path)
    stop_protect = False

    for volume in volumes:
        volume_re = r'^\{}\/'.format(volume)
        if re.match(volume_re, target_path):
            stop_protect =True
            break

    if stop_protect:
        status = subprocess.call([bin_systemctl, 'mask', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=10)
        if 0 != status:
            sys.exit(5)
        status = subprocess.call([bin_systemctl, 'stop', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=60)
        if 0 != status:
            sys.exit(6)

    time.sleep(0.25)
    sys.exit(0)
