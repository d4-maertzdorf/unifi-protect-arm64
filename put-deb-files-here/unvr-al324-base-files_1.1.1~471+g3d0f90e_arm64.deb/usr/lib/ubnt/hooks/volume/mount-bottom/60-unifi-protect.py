#!/usr/bin/python3

import os
import subprocess
import sys
import time


bin_systemctl          = '/bin/systemctl'
service_unifi_protect  = 'unifi-protect.service'
srv_path               = '/srv'


if __name__ == "__main__":
    if not os.path.islink(srv_path):
        sys.exit(2)

    target_path = os.readlink(srv_path)
    if not os.path.exists(target_path):
        sys.exit(3)

    status = subprocess.call([bin_systemctl, 'unmask', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=10)
    if 0 != status:
        sys.exit(4)

    status = subprocess.call([bin_systemctl, 'restart', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=60)
    if 0 != status:
        sys.exit(5)

    time.sleep(0.25)
    sys.exit(0)
