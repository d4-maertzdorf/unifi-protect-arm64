#!/usr/bin/python3

import os
import subprocess
import sys
import time


bin_systemctl          = '/bin/systemctl'
service_pgsql          = 'postgresql@9.6-protect.service'
service_pgsql_setup    = 'postgresql-cluster@9.6-protect.service'
service_unifi_protect  = 'unifi-protect.service'
srv_path               = '/srv'
etc_systemd_dir        = '/etc/systemd/system/'


def condition_srv_gen(service_name):
    service_dir = '{}/{}.d/'.format(etc_systemd_dir, service_name)
    config_path = '{}/condition-srv.conf'.format(service_dir)
    condition_srv = '[Unit]\nConditionPathIsSymbolicLink={}\n'.format(srv_path)

    if os.path.isfile(config_path):
        return True

    try:
        os.makedirs(service_dir, exist_ok=True)
    except:
        return False

    try:
        with open(config_path, 'w') as f:
            f.write(condition_srv)
    except:
        return False

    return True


if __name__ == "__main__":
    if not os.path.islink(srv_path):
        sys.exit(2)

    target_path = os.readlink(srv_path)
    if not os.path.exists(target_path):
        sys.exit(3)

    status = subprocess.call([bin_systemctl, 'mask', service_unifi_protect, service_pgsql, service_pgsql_setup], stdout=subprocess.DEVNULL, timeout=10)
    if 0 != status:
        sys.exit(4)

    # for noHDD protect
    status = subprocess.call([bin_systemctl, 'stop', service_unifi_protect], stdout=subprocess.DEVNULL, timeout=60)
    if 0 != status:
        sys.exit(5)

    # for noHDD protect
    status = subprocess.call([bin_systemctl, 'stop', service_pgsql], stdout=subprocess.DEVNULL, timeout=60)

    time.sleep(0.25)

    if condition_srv_gen(service_pgsql) is False:
        sys.exit(6)
    if condition_srv_gen(service_pgsql_setup) is False:
        sys.exit(7)
    if condition_srv_gen(service_unifi_protect) is False:
        sys.exit(8)
    subprocess.call([bin_systemctl, 'daemon-reload'], stdout=subprocess.DEVNULL, timeout=10)

    status = subprocess.call([bin_systemctl, 'unmask', service_pgsql, service_pgsql_setup], stdout=subprocess.DEVNULL, timeout=10)
    if 0 != status:
        sys.exit(9)

    status = subprocess.call([bin_systemctl, 'restart', service_pgsql_setup], stdout=subprocess.DEVNULL, timeout=60)
    if 0 != status:
        sys.exit(10)

    time.sleep(0.25)
    sys.exit(0)
