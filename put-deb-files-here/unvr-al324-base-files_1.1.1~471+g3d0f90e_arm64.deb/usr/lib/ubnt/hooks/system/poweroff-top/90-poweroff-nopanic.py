#!/usr/bin/python3

import json
import sys


key_action       = 'action'
poweroff_action  = 'poweroff'
panic_level_path = '/proc/sys/kernel/panic'


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)

    j_args = None
    try:
        j_args = json.loads(sys.argv[1])
    except:
        sys.exit(2)

    if not key_action in j_args.keys():
        sys.exit(3)

    action = j_args[key_action]

    if action != poweroff_action:
        sys.exit(0)

    try:
        with open(panic_level_path, 'w') as f:
            f.write('0')
    except:
        sys.exit(1)

    sys.exit(0)
