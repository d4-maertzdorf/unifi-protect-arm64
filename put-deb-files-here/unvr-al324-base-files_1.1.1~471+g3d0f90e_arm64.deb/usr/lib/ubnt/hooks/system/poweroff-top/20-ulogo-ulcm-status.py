#!/usr/bin/python3

import os
import stat
import subprocess
import json
import sys


key_action       = 'action'
poweroff_action  = 'poweroff'
reboot_action    = 'reboot'
ulcm_device_path = '/dev/ttyACM0'
ubntnvr          = '/usr/bin/ubntnvr'
ulcmd            = '/usr/bin/ulcmd'


def lcm_control(state):
    try:
        subprocess.call([ulcmd, '--sender', 'system-hook', '--command', state],
                        stdout=subprocess.DEVNULL)
    except:
        return False

    return True


if __name__ == "__main__":
    if not os.path.exists(ulcm_device_path) or not stat.S_ISCHR(os.lstat(ulcm_device_path)[stat.ST_MODE]):
        status = subprocess.call([ubntnvr, 'ulogo', 'default'], stdout=subprocess.DEVNULL)
        if 0 != status:
            sys.exit(2)

        sys.exit(0)

    if len(sys.argv) != 2:
        sys.exit(3)

    j_args = None
    try:
        j_args = json.loads(sys.argv[1])
    except:
        sys.exit(4)

    if not key_action in j_args.keys():
        sys.exit(5)

    action = j_args[key_action]

    if action == poweroff_action:
        if lcm_control('poweroff') is False:
            sys.exit(5)
    elif action == reboot_action:
        if lcm_control('restart') is False:
            sys.exit(6)

    sys.exit(0)
