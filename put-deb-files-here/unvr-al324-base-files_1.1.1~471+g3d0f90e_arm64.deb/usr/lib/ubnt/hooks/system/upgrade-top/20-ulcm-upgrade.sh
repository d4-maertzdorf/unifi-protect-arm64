#!/bin/bash

if [ -x /usr/bin/ulcmd ]; then
    /usr/bin/ulcmd --sender system-hook --command update
fi

exit 0
