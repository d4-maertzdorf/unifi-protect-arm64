#!/bin/bash

sync;sync;sync

exit 0
