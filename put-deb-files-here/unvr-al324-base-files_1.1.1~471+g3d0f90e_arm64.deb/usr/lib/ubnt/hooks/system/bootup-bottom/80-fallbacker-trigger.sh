#!/bin/bash

touch /run/systemd/netif/links/fallbacker-trigger
rm /run/systemd/netif/links/fallbacker-trigger

exit 0
