#!/bin/bash

if [ -x /usr/bin/ulcmd ]; then
    /usr/bin/ulcmd --sender system-hook --command reset
fi

exit 0
