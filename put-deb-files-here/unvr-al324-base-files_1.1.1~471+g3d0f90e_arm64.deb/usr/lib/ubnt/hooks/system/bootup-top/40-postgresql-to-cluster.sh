#!/bin/bash

if [ -e "/data/db/postgresql/9.6/main" ] && [ ! -e "/data/postgresql/9.6/main" ]; then
  mkdir -p /data/postgresql/9.6/main
  mv /etc/postgresql/9.6/main /data/postgresql/9.6/main/conf
  ln -sf /data/postgresql/9.6/main/conf /etc/postgresql/9.6/main
  mv /data/db/postgresql/9.6/main /data/postgresql/9.6/main/data
  sed -i 's/\/data\/db\/postgresql\/9.6\/main/\/data\/postgresql\/9.6\/main\/data/g' /data/postgresql/9.6/main/conf/postgresql.conf
  mv /data/postgresql/9.6/main/data/.configured /data/postgresql/9.6/main
  chown -R postgres:postgres /data/postgresql/9.6/main
  rm -rf /data/db
fi
