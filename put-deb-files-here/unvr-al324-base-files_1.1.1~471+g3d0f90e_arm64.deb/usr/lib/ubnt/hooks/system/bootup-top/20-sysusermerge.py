#!/usr/bin/python3

import json
import os
import re
import subprocess
import sys


sbin_sysusermerge      = '/sbin/sysusermerge'
ro_root                = '/mnt/.rofs/'
rw_root                = '/'

key_upgrade_boot       = 'upgradeBoot'
key_reset_boot         = 'resetBoot'
key_recover_boot       = 'recoverBoot'


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)

    j_args = None
    try:
        j_args = json.loads(sys.argv[1])
    except:
        sys.exit(2)

    if not key_upgrade_boot in j_args.keys() or not key_reset_boot in j_args.keys() or not key_recover_boot in j_args.keys():
        sys.exit(3)

    if j_args[key_upgrade_boot] != True:
        sys.exit(0)
    if j_args[key_reset_boot] == True:
        sys.exit(0)

    subprocess.call([sbin_sysusermerge, ro_root, rw_root], stdout=subprocess.DEVNULL)

    sys.exit(0)
