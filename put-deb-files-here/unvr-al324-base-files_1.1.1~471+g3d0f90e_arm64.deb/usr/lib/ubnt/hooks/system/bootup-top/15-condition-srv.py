#!/usr/bin/python3

import os
import subprocess
import sys


bin_systemctl          = '/bin/systemctl'
service_pgsql          = 'postgresql@9.6-protect.service'
service_pgsql_setup    = 'postgresql-cluster@9.6-protect.service'
service_unifi_protect  = 'unifi-protect.service'
srv_path               = '/srv'
etc_systemd_dir        = '/etc/systemd/system/'


def condition_srv_gen(service_name):
    service_dir = '{}/{}.d/'.format(etc_systemd_dir, service_name)
    config_path = '{}/condition-srv.conf'.format(service_dir)
    condition_srv = '[Unit]\nConditionPathIsSymbolicLink={}\n'.format(srv_path)

    if os.path.isfile(config_path):
        return True

    try:
        os.makedirs(service_dir, exist_ok=True)
    except:
        return False

    try:
        with open(config_path, 'w') as f:
            f.write(condition_srv)
    except:
        return False

    return True


if __name__ == "__main__":
    if not os.path.islink(srv_path):
        sys.exit(0)

    target_path = os.readlink(srv_path)
    if not os.path.exists(target_path):
        sys.exit(2)

    if condition_srv_gen(service_pgsql) is False:
        sys.exit(3)
    if condition_srv_gen(service_pgsql_setup) is False:
        sys.exit(4)
    if condition_srv_gen(service_unifi_protect) is False:
        sys.exit(5)
    subprocess.call([bin_systemctl, 'daemon-reload'], stdout=subprocess.DEVNULL, timeout=10)

    sys.exit(0)
