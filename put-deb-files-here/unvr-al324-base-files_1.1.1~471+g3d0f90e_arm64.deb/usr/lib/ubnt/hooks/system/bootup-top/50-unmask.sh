#!/bin/bash
# vim: ts=4:sw=4:expandtab

systemctl unmask unifi-protect

