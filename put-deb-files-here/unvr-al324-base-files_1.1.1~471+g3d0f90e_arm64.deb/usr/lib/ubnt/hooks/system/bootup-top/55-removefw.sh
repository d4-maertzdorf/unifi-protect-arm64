#!/bin/bash
# vim: ts=4:sw=4:expandtab

if [ -e "/var/cache/fwupdate/" ]; then
	rm -f /var/cache/fwupdate/*
fi
