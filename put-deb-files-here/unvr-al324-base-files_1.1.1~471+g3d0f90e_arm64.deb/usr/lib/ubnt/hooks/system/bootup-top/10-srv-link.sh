#!/bin/bash

/usr/sbin/srv-gen
